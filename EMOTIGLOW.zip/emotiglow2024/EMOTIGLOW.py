#################################### LIBRARIES ####################################
import pygame
import cv2
# importing constants and sets up pygame screen
from emotiglow_setup import *
from emotiglow_textsetups import *
from emotiglow_buttonconstants import *
from emotiglow_screensetups import *
from collections import deque
from deepface import DeepFace

################################# CIRCLE CLASS #################################
# SINGLE CIRCLES
class ColorCircle:
    # CLASS VARIABLES
    # radius is the same for every circle
    radius = 20

    def __init__ (self, x, y, color1, color2):
        # INSTANCE VARIABLES
        # x, y, and the colors of the circle will vary
        self.x = x
        self.y = y
        # color 1 is the color of the object
        self.color1 = color1
        # purpose of color2 is to get the color gradient
        self.color2 = color2
        # creating a tuple from the object's x and y coordinates
        self.position = (self.x, self.y)

    def drawCircle(self, screen):
        # draws circles based on parameters if in 'manual' mode
        pygame.draw.circle(screen, self.color1, self.position, self.radius)
    
    def hideCircle(self):
        # draws circles the background color if not in 'manual' mode
        pygame.draw.circle(screen, background, self.position, self.radius)
        
    def ifClicked(self, mousex, mousey):
        # if the mouse clicks a circle....
        if ((mousex - self.x) ** 2 + (mousey - self.y) ** 2) <= (self.radius ** 2):
            # return color1 and color2 to be used later as a gradient
            return self.color1, self.color2
        
# loading pretrained haar face recognition model
cascader = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

# create a queue data structure for emotion return values
emotion_queue = deque(maxlen=135)

#################################### FUNCTIONS ####################################
# blits every element for 'start' screen
def startScreen():
    startB.fill((188, 217, 255))
    screen.blit(startB, (startB_x, startB_y))
    screen.blit(logo, (50, -35))
    screen.blit(start_text, (250, 455))

# hides every element on 'start' screen
def hideStartScreen():
    startB.fill(background)
    screen.blit(logo, (50, -35))
    start_text = title_font.render("START", True, (background))
    screen.blit(start_text, (250, 455))
    screen.blit(startB, (startB_x, startB_y))  

# blits every element for 'control' screen
def controlScreen():
    screen.blit(choosemode_text, (12.5, 250))
    screen.blit(choosemode_text2, (12.5, 300))
    screen.blit(surf, (12.5, 45))
    screen.blit(surf2, (400, 45))
    screen.blit(surf3, (415, 120))
    screen.blit(title_text, (12.5, 0))
    screen.blit(STATUS, (420,90))
    screen.blit(MODE, (420,150))
    screen.blit(text_scanning, (scanning_x,scanning_y))
    screen.blit(text_manual, (manual_x, manual_y))
    screen.blit(ABOUT, (ABOUT_x, ABOUT_y))
    screen.blit(logo2, (400, 200))

# blits every element for 'about' screen
def aboutScreen():
    screen.fill((228, 230, 255))
    about_info.fill((188, 217, 255))
    screen.blit(about_info, (30, 210))
    screen.blit(photo, (175, 20))
    screen.blit(authors_text, (85, 225))
    screen.blit(aboutit, (45, 250))
    screen.blit(aboutit2, (57, 270))
    screen.blit(aboutit3, (45, 290))
    screen.blit(aboutit4, (57, 310))
    screen.blit(red_text, (57, 330))
    screen.blit(yellow_text, (57, 350))
    screen.blit(green_text, (57, 370))
    screen.blit(gbduo_text, (57, 390))
    screen.blit(gbduo_text2, (57, 410))
    screen.blit(lb_text, (57, 430))
    screen.blit(bduo_text, (57, 450))
    screen.blit(purple_text, (57, 470))
    screen.blit(purple_text2, (57, 490))
    screen.blit(backbtn_text, (backbtn_x, backbtn_y))

# gets the color gradient between color2 and color2
def blendColor(color1, color2, alpha):
    r = int(color1[0] * (1 - alpha) + color2[0] * alpha)
    g = int(color1[1] * (1 - alpha) + color2[1] * alpha)
    b = int(color1[2] * (1 - alpha) + color2[2] * alpha)
    # returns the gradient
    return (r, g, b)

# executes the gradient from color1 to color2
def gradient(color1, color2):
    # calculates alpha based on time
    time_elapsed = pygame.time.get_ticks() % transitionSpeed
    alpha = abs(time_elapsed / transitionSpeed - 0.5) * 2
    currentColor = blendColor(color1, color2, alpha)
    surf.fill(currentColor)
     
def checkCircles():
    # iterating through each circle object
    for circle in color_circles:
        # checking to see if any of the circles were clicked
        clicked_colors = circle.ifClicked(mousex, mousey)
        if clicked_colors:
            color1, color2 = clicked_colors
            # returns color1 and color2 to be used later for gradient
            return color1, color2
        
    # if nothing is clicked, keep color1 and color2 as whatever it currently is
    return current1, current2
    
# draws circles from ColorCircle background color if not in 'manual' mode
def hideCircles():
    for circle in color_circles:
        circle.hideCircle()
        
# draws circles from ColorCircle if in 'manual' mode
def showCircles():
    for circle in color_circles:
        circle.drawCircle(screen)

# Function to detect and recognize faces in the frame
def detect_faces(frame):
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = cascader.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))
    for (x, y, w, h) in faces:
        # Draw rectangle around detected face
        cv2.rectangle(frame, (x, y), (x+w, y+h), (255, 0, 0), 2)

        # Extract face region for emotion detection
        face = frame[y:y+h, x:x+w]

        try:
            # Analyze current frame and add emotion to queue
            results = DeepFace.analyze(img_path=frame, actions=['emotion'])
            for result in results:
                emotions = result['emotion']
                emotion = max(emotions, key=emotions.get)
                cv2.putText(frame, emotion, (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)
                emotion_queue.append(emotion)
        except Exception as e:
            print("Error:", str(e))

    return frame


# function to process and handle webcam
def run_webcam():
    cap = cv2.VideoCapture(0)
    while True:
        ret, frame = cap.read()
        if not ret:
            break

        frame = detect_faces(frame)

        # Determine the most prevalent emotion in the queue
        if len(emotion_queue) > 0:
            emotion_counts = {}
            for emotion in emotion_queue:
                emotion_counts[emotion] = emotion_counts.get(emotion, 0) + 1

            prevalent_emotion = max(emotion_counts, key=emotion_counts.get)
            if prevalent_emotion == 'happy':
                surf.fill(red)
            if prevalent_emotion == 'sad':
                surf.fill(yellow)
            if prevalent_emotion == 'angry':
                surf.fill(green)
            if prevalent_emotion == 'fear':
                surf.fill(lightblue)
            if prevalent_emotion == 'neutral':
                surf.fill(darkblue)
            if prevalent_emotion == 'disgust':
                surf.fill(purple)


            # Display the most prevalent emotion
            cv2.putText(frame, f"Prevalent Emotion: {prevalent_emotion}", (10, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 0, 0), 2)

        # Display the resulting frame
        cv2.imshow('Facial Recognition & Emotion Detection', frame)

        # Exit when 'q' is pressed
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()

##################################### SETUPS #####################################

# this list contains every single colored circle object
color_circles = []

# creating single colors
color_circles.append(ColorCircle(30, 295, red, red))  
color_circles.append(ColorCircle(75, 295, yellow, yellow)) 
color_circles.append(ColorCircle(120, 295, green, green)) 
color_circles.append(ColorCircle(165, 295, lightblue, lightblue))
color_circles.append(ColorCircle(210, 295, darkblue, darkblue)) 
color_circles.append(ColorCircle(255, 295, purple, purple)) 
# creating the duos
color_circles.append(ColorCircle(30, 365, red, yellow))
color_circles.append(ColorCircle(70.5, 365, yellow, red)) 
color_circles.append(ColorCircle(30, 415, yellow, green))
color_circles.append(ColorCircle(70.5,415, green, yellow))
color_circles.append(ColorCircle(30, 465, green, lightblue)) 
color_circles.append(ColorCircle(70.5, 465, lightblue, green)) 
color_circles.append(ColorCircle(143, 365, lightblue, darkblue))  
color_circles.append(ColorCircle(183.5, 365, darkblue, lightblue))
color_circles.append(ColorCircle(143, 415, darkblue, purple)) 
color_circles.append(ColorCircle(183.5, 415, purple, darkblue))  
color_circles.append(ColorCircle(143, 465, purple, red))  
color_circles.append(ColorCircle(183.5, 465, red, purple)) 

# setting up booleans
# the point of these booleans is to determine when certain screens/text/objects should be visible
Duos = False
Coloring = False
Control = False
Start = True
About = False
Hidden = False
Camera = False
Red = False
Yellow = False

###################################### MAIN ######################################
running = True
while running:
    # setting up background color
    screen.fill((background))

    for event in pygame.event.get():
        Start = True
        if event.type == pygame.QUIT:
            running = False

        # if mouse is pressed...
        elif event.type == pygame.MOUSEBUTTONDOWN:
            # get current coordinates of mouse
            mousex, mousey = pygame.mouse.get_pos()

            # if 'start' button is pressed...
            if (startB_x <= mousex <= startB_x + startB_width and
                startB_y <= mousey <= startB_y + startB_height):
                # if it was, hide 'start' screen and set up 'control' screen
                Start = False
                Control = True

            # if 'about' button is pressed...
            if (ABOUT_x <= mousex <= ABOUT_x + ABOUT_width and
                ABOUT_y <= mousey <= ABOUT_y + ABOUT_height):
                # hide 'contro'l screen and set up 'about' screen
                Control = False
                About = True
                # coloring "scanning" and "manual" are back to default color, turning off both modes
                text_scanning = body_font.render("* scanning", True, (3, 12, 33))
                text_manual = body_font.render("* manual", True, (3, 12, 33))
                
            # if 'back' button is pressed...
            if (backbtn_x <= mousex <= backbtn_x + backbtn_width and
                backbtn_y <= mousey <= backbtn_y + backbtn_height):
                # go back to 'control' screen and hide 'about' screen
                Control = True
                Start = False
                About = False
                Camera = False

            # if "manual" is pressed...
            if (manual_x <= mousex <= manual_x + manual_width and
                manual_y <= mousey <= manual_y + manual_height):
                # bring color circles onto the screen and turn off facial recognition
                Coloring = True
                Camera = False
                # coloring "scanning" and "manual" so the user knows what mode they are in
                text_scanning = body_font.render("* scanning", True, (3, 12, 33))
                text_manual = body_font.render("* manual", True, (red))

            # if "scanning" is pressed...
            if (scanning_x <= mousex <= scanning_x + scanning_width and
                scanning_y <= mousey <= scanning_y + scanning_height):
                # hide colored circles, set up facial recognition
                Camera = True
                Coloring = False
                # coloring "scanning" and "manual" so the user knows what mode they are in
                text_scanning = body_font.render("* scanning", True, (red))
                text_manual = body_font.render("* manual", True, (3, 12, 33))

            # if color circles are pressed, return the circle's color1 and color2
            color1, color2 = checkCircles()
                             
    # results of setting each boolean to true/false
    if Coloring == False:
        # turns off 'manual' screen and makes circles background color
        hideCircles()
    
    if Start == True:
        # set up 'start' screen
        startScreen()

    if Control == True:
        # sets up 'control' screen
        logo = pygame.image.load("images/blank.png").convert_alpha()
        hideStartScreen()
        controlScreen()
        
    if About == True:
        # sets up 'about' screen
        aboutScreen()
        Coloring = False
        # hiding this text from 'control' screen if switched to about page
        choosemode_text = starting_font.render("CHOOSE A MODE", True, (background))
        choosemode_text2 = starting_font.render("TO BEGIN :)", True, (background))   

    if Coloring == True:
        # turns on 'manual' mode
        # hiding this text from 'control' screen if this mode is chosen
        choosemode_text = starting_font.render("CHOOSE A MODE", True, (background))
        choosemode_text2 = starting_font.render("TO BEGIN :)", True, (background))
        # showing text for manual mode
        color_title_text = body_font.render("select a color:", True, (3, 12, 33))
        color_duo_command = body_font.render("OR select a duo:", True, (13, 12, 33))
        color_custom_command = caption_font.render("duos are cycled back and forth", True, (166, 166, 166))        
        screen.blit(color_title_text, (12.5, 250))
        screen.blit(color_duo_command, (12.5, 320))
        screen.blit(color_custom_command, (12.5, 490))
        # drawing the color circles
        showCircles()
        # keeping coolor of surface the same if nothing new is clicked...
        current1 = color1
        current2 = color2
        # executes the gradient of color1 and color2
        gradient(color1, color2)
    
    # If Camera mode is activated, run webcam
    if Camera == True:
        run_webcam()
        Camera = False

    # updating display
    pygame.display.flip()
    clock.tick(60)

pygame.quit()
