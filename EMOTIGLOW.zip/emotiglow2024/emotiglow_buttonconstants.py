# LIBRARIES
import pygame
import os
import math
from emotiglow_setup import *
from emotiglow_textsetups import *

# CONSTANTS
# start button
startB_x = 80
startB_y = 456
startB_width = 450
startB_height = 50
# about button
ABOUT_x = 520
ABOUT_y = 450
ABOUT_width = ABOUT.get_rect().width
ABOUT_height = ABOUT.get_rect().height
# back button
backbtn_x = 30
backbtn_y = 530
backbtn_width = backbtn_text.get_rect().width
backbtn_height = backbtn_text.get_rect().height
# scanning button
scanning_x = 420
scanning_y = 170
scanning_width = text_scanning.get_rect().width
scanning_height = text_scanning.get_rect().height
# manual button
manual_x = 420
manual_y = 190
manual_width = text_scanning.get_rect().width
manual_height = text_scanning.get_rect().height
