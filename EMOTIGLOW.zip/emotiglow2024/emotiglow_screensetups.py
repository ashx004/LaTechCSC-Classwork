# LIBRARIES
import pygame
import os
import math
from emotiglow_setup import *
from emotiglow_textsetups import *
from emotiglow_buttonconstants import *

# SETTING UP LAYOUTS
# START SCREEN:
startB = pygame.Surface((startB_width, startB_height))
rect = startB.get_rect()
logo = pygame.image.load("images/logo.png").convert_alpha()
rect2 = logo.get_rect()
scaled_width = logo.get_width() // 4
scaled_height = logo.get_height() // 4
logo = pygame.transform.scale(logo, (scaled_width, scaled_height))
# CONTROL SCREEN:
surf = pygame.Surface((350, 200))
surf.fill((188, 217, 255))
rect = surf.get_rect()
logo2 = pygame.image.load("images/logo2.png").convert_alpha()
surf2 = pygame.Surface((200, 450))
surf2.fill((188, 217, 255))
rect2 = surf.get_rect()
scaled_width = logo2.get_width() // 10.25
scaled_height = logo2.get_height() // 10.25
logo2 = pygame.transform.scale(logo2, (scaled_width, scaled_height))
surf3 = pygame.Surface((170, 30))
surf3.fill((0, 0, 0))
rect3 = surf.get_rect()
# ABOUT SCREEN
photo = pygame.image.load("images/group.jpg").convert_alpha()
rect7 = photo.get_rect()
scaled_width = photo.get_width() // 7.5
scaled_height = photo.get_height() // 7.5
photo = pygame.transform.scale(photo, (scaled_width, scaled_height))
about_info = pygame.Surface((560, 320))
rect = about_info.get_rect()
