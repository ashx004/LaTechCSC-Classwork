# LIBRARIES
import pygame
import os
import math

# COLOR CONSTANTS
red = (255, 49, 49)
yellow = (255, 222, 89)
green = (114, 255, 133)
lightblue = (92, 225, 230)
darkblue = (0, 74, 173)
purple = (240, 82, 255)
background = (228, 230, 255)
current1 = (188, 217, 255)
current2 = (188, 217, 255)

# SETTING UP
pygame.init()
screen_width = 620
screen_height = 550
screen = pygame.display.set_mode([screen_width, screen_height])
pygame.display.set_caption("EMOTIGLOW")
clock = pygame.time.Clock()
transitionSpeed = 2000
