# LIBRARIES
import pygame
import os
import math
from emotiglow_setup import *

# setting up fonts
title_font = pygame.font.Font(os.path.join("fonts", "Poppins-Bold.ttf"), 36)
body_font = pygame.font.Font(os.path.join("fonts", "Poppins-Medium.ttf"), 18)
caption_font = pygame.font.Font(os.path.join("fonts", "Poppins-Medium.ttf"), 12)
subs = pygame.font.Font(os.path.join("fonts", "Poppins-Bold.ttf"), 18)
authors_font = pygame.font.Font(os.path.join("fonts", "Poppins-Medium.ttf"), 12)
starting_font = pygame.font.Font(os.path.join("fonts", "Poppins-Medium.ttf"), 40)

# setting up start screen text
start_text = title_font.render("START", True, (3, 12, 33))
# setting up control screen text
choosemode_text = starting_font.render("CHOOSE A MODE", True, (3, 12, 33))
choosemode_text2 = starting_font.render("TO BEGIN :)", True, (3, 12, 33))
title_text = title_font.render("EMOTIGLOW", True, (3, 12, 33))
color_title_text = body_font.render("select a color:", True, (3, 12, 33))
color_duo_command = body_font.render("OR select a duo:", True, (13, 12, 33))
color_custom_command = caption_font.render("duos are cycled back and forth", True, (166, 166, 166))
STATUS = subs.render("STATUS:", True, (3, 12, 33))
MODE = subs.render("MODE:", True, (3, 12, 33))
text_scanning = body_font.render("* scanning", True, (3, 12, 33))
text_manual = body_font.render("* manual", True, (3, 12, 33))
SETTINGS = subs.render("SETTINGS", True, (3, 12, 33))
LOGOUT = subs.render("LOG OUT", True, (3, 12, 33))
ABOUT = subs.render("ABOUT", True, (3, 12, 33))

# setting up about screen text
authors_text = authors_font.render("CREATED BY: JENNY WRIGHT, TESS GARDNER, ASHTON HARRELL, TIA RANSOM", True, (5, 12, 28))
aboutit = body_font.render("* Emotiglow uses uses tiny boxes to read facicial", True, (3, 12, 33))
aboutit2 = body_font.render(" structures and changes the light based on mood ", True, (3, 12, 33))
aboutit3 = body_font.render("* Emotiglow uses color theory to decide what color is", True, (3, 12, 33))
aboutit4 = body_font.render("most appropriate", True, (3, 12, 33))
red_text = body_font.render("HAPPY  -> RED (feelings of excitement & enthusiasm", True, (red))
yellow_text = body_font.render("SAD -> YELLOW (symbol of joy, happiness, energy)", True, (168, 168, 32))
green_text = body_font.render("ANGRY -> GREEN (calming, motivating, healthful)", True, (27, 161, 83))
gbduo_text = body_font.render("SURPRISE -> GREEN BLUE DUO (symbol of tranquility, ", True, (33, 207, 178))
gbduo_text2 = body_font.render("peace, motivation, good health)", True, (33, 207, 178))
lb_text = body_font.render("FEAR -> LIGHT BLUE (symbol of tranquility & peace)", True, (18, 199, 219))
bduo_text = body_font.render("NEUTRAL -> BLUE DUO (symbol of calmness & relaxation)", True, (darkblue))
purple_text = body_font.render("DISGUST -> PURPLE (shades of green can represent", True, (purple))
purple_text2 = body_font.render("disgust; purple is complementary to green)", True, (purple))
backbtn_text = authors_font.render("BACK", True, (5, 12, 28))




